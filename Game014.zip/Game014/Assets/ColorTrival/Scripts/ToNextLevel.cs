﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ColorTrival{


public class ToNextLevel : MonoBehaviour {
	public bool isWork = false;
	public Vector3 upSpeedV3 = new Vector3(0.0f, 100.0f, 0.0f);
	public float upLevelMax = 30.0f;
	public string sceneName = "Level1";

	private float upLevel;
	void Awake()
	{
		upLevel = 0.0f;
	}
	void Start () {
		
	}
	void Update () {
		if(isWork)
		{
			this.transform.position += upSpeedV3 * Time.deltaTime;
			upLevel += upSpeedV3.y * Time.deltaTime;
			if(upLevel >= upLevelMax)
			{
				SceneManager.LoadScene(sceneName);
			}
		}
	}
	void OnTriggerEnter(Collider col)
	{
		if(col.CompareTag("Player"))
		{
			col.transform.SetParent(this.transform);
			col.GetComponent<FirstPlayerController>().isDead = true;
			isWork = true;
		}
	}
	// void OnTriggerExit(Collider col)
	// {
	// 	if(col.CompareTag("Player"))
	// 	{
	// 		col.transform.SetParent(null);
	// 	}
	// }
}


}
