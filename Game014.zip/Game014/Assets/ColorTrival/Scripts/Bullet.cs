﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{



public class Bullet : MonoBehaviour {

	private float flySpeed = 100.0f;
	private float flyTime = 3.0f;
	void Awake() {
	}

	void Start () {
		Destroy(this.gameObject,flyTime);
	}
	void Update () {
		this.transform.position += this.transform.forward * flySpeed * Time.deltaTime;
	}
	void OnTriggerEnter(Collider col)
	{
		if(col.CompareTag("ColorMonster"))
		{
			Explotion();
		}
		else if(col.CompareTag("ColorTrap"))
		{
			Explotion();
		}
		else if(col.CompareTag("Untagged"))
		{
			Explotion();
		}
	}

	private void Explotion()
	{
		Destroy(this.gameObject,0.0f);
	}


	
}
}
