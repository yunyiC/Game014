﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{
public class TestzhuixingHurt : MonoBehaviour {
	void Start () {
		
	}
	void Update () {
		
	}
	void OnTriggerStay(Collider col)
	{
		if(col.CompareTag("ColorMonster"))
		{
			ColorMonster T = col.GetComponent<ColorMonster>();
			T.Hurt(100);
		}
	}
}
}
