﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ColorTrival{

public enum Operate{
	Continue = 0,
	LoadLevelT = 1,
	LoadLevel1 = 3,
	LoadLevel2 = 4,
	LoadLevel3 = 5,
	QuitGame = 6,
	Destroy = 7,
	OpenMenu = 8,
}
public class Operating : MonoBehaviour {

	public Operate OP;
	public float workCoolMax = 1.0f;

	private float workCoolTime;
	private void Awake() {
		workCoolTime = 0.0f;
	}
	void Start () {
		
	}
	void Update () {
		
	}
	public void Work()
	{
		switch(OP)
		{
			case Operate.Continue:GameManager.MENU.Continue();break;
			case Operate.LoadLevelT:GameManager.LoadScene("LevelT");break;
			case Operate.LoadLevel1:GameManager.LoadScene("Level1");break;
			case Operate.LoadLevel2:GameManager.LoadScene("Level2");break;
			case Operate.LoadLevel3:GameManager.LoadScene("Level3");break;
			case Operate.QuitGame:GameManager.Quit();break;
			case Operate.Destroy:Destroy(this.gameObject,0.0f);break;
			case Operate.OpenMenu:GameManager.MENU.Pause();break;
			default:break;
		}
	}
}



}
