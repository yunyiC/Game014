﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace ColorTrival{


public class Turret : MonoBehaviour {

	[Tooltip("死亡高度")]public float deadLine = -15.0f;
	[Tooltip("扫描速度")]public float rotateSpeed = 2.0f;
	[Tooltip("射击半径")]public float shootRadius = 20.0f;
	[Tooltip("伤害值")] public int hurtValue = 100;
	[Tooltip("射击冷却时间")] public float shootCoolDown = 0.2f;
	[Tooltip("子弹预置体")] public GameObject bulletPrefab;
	[Tooltip("炮塔枪管部分")] public Transform head;
	[Tooltip("炮塔中心")] public Transform center;

	private Transform target;
	private Ray ray;
	private RaycastHit hit;
	private int layerMask;
	private float distanceT;
	private float shootCoolLevel;
	
	
	void Awake()
	{
		shootCoolLevel = 0.0f;
		layerMask = 1 << 9;
		layerMask = ~layerMask;
	}
	void Start () {
	}
	
	void Update () 
	{
		if(this.transform.position.y < deadLine)
		{
			Destroy(this.gameObject,0.0f);
		}
		Aiming();
		Shooting();
	}
	private void Aiming()
	{
		if(target != null)
		{
			head.LookAt(new Vector3(target.position.x,head.position.y,target.position.z));
		}
		else
		{
			head.eulerAngles = new Vector3(0.0f,head.eulerAngles.y,0.0f);
			head.RotateAround(center.position,Vector3.up,rotateSpeed);//自转
			ray = new Ray(head.position,head.forward);
			Debug.DrawLine(head.position,head.forward*shootRadius);
			if(Physics.Raycast(ray,out hit,shootRadius,layerMask))
			{
				if(hit.transform.CompareTag("ColorMonster"))
				{
					target = hit.transform;
				}
				else if(hit.transform.CompareTag("GreenMonster"))
				{
					target = hit.transform;
				}
			}
		}
	}
	private void Shooting()
	{
		shootCoolLevel -= Time.deltaTime;
		if(target != null)
		{
			distanceT = Vector3.Distance(head.position,target.position);
			if(distanceT >= shootRadius)
			{
				target = null;
			}
			else if(shootCoolLevel <= 0.0f)
			{
				GameObject.Instantiate(bulletPrefab,center.transform.position,Quaternion.Euler(center.eulerAngles));
				if(target.CompareTag("ColorMonster"))
				{
					target.GetComponent<ColorMonster>().Hurt(hurtValue);
				}
				else if(target.CompareTag("GreenMonster"))
				{
					target.GetComponent<GreenMonster>().Hurt(hurtValue);
				}
				shootCoolLevel = shootCoolDown;
			}
		}
	}

	// private void RotateT()
	// {
	// 	// direction = target.position - center.position;
	// 		// float rotateAngleT = Vector3.Angle(center.forward,direction);
	// 		// Debug.Log("角度：" + rotateAngleT);
	// 		// while(rotateAngleT > 90.0f)
	// 		// {
	// 		// 	rotateAngleT -= 180.0f;
	// 		// }
	// 		// while(rotateAngleT < -90.0f)
	// 		// {
	// 		// 	rotateAngleT += 180.0f;
	// 		// }
	// 		// this.transform.RotateAround(center.position,Vector3.up,-rotateSpeed);
	// }
	// private void ShootT(Transform target)
	// {
	// 	GameObject bulletT = GameObject.Instantiate(bulletPrefab,center.transform.position,Quaternion.identity) as GameObject;
	// 	Bullet bulletScript = bulletT.GetComponent<Bullet>();
	// 	bulletScript.hurtTag = "Player";
	// 	bulletScript.hurtValue = hurtValue;
	// 	bulletT.GetComponent<Rigidbody>().AddForce(direction * bulletSpeed);
	// 	isShootCold = true;
	// 	Invoke("ShootColded",shootCD);
	// }
}


}
