﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class UIManager : MonoBehaviour {

	[Tooltip("第二血量")] public static GameObject objSecondBlood;
	// [Tooltip("玩家血量")] public static GameObject objPlayerBlood;
	// [Tooltip("玩家Buff")] public static GameObject objPlayerBuff;
	// [Tooltip("玩家技能")] public static GameObject objPlayerSkills;
	// [Tooltip("玩家射击")] public static GameObject objPlayerShoot;
	// [Tooltip("玩家金币")] public static GameObject objPlayerGold;
	[Tooltip("玩家血量")] public static UIPlayerBlood playerBloodUI;
	[Tooltip("玩家Buff")] public static UIPlayerBuff playerBuffUI;
	[Tooltip("第二血量")] public static UISecondBlood secondBloodUI;
	[Tooltip("玩家技能")] public static UIPlayerSkills playerSkillsUI;	
	[Tooltip("玩家射击")] public static UIPlayerShoot playerShootUI;
	[Tooltip("玩家金币")] public static UIPlayerGold playerGoldUI;
	[Tooltip("提示")] public static UIDialogue dialogueUI;
	void Awake() {
		objSecondBlood = this.transform.Find("SecondBloodUI").gameObject;

		playerBloodUI = this.GetComponentInChildren<UIPlayerBlood>();
		playerBuffUI = this.GetComponentInChildren<UIPlayerBuff>();
		secondBloodUI = this.GetComponentInChildren<UISecondBlood>();
		playerSkillsUI = this.GetComponentInChildren<UIPlayerSkills>();
		playerShootUI = this.GetComponentInChildren<UIPlayerShoot>();
		playerGoldUI = this.GetComponentInChildren<UIPlayerGold>();
		dialogueUI = this.GetComponentInChildren<UIDialogue>();
	}
	void Start () {
		
	}
	void Update () {
		
	}

	public static void SetSecondBloodShow(bool isShow)
	{
		if(isShow)
		{
			objSecondBlood.SetActive(true);
		}
		else
		{
			objSecondBlood.SetActive(false);
		}
	}
}


}
