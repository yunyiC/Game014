﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class Laser : MonoBehaviour {

	private Shoot shootScript;
	void Awake()
	{
		shootScript = GameManager.player.GetComponent<Shoot>();
	}
	void Start () {
		
	}
	void Update () {
		
	}
	private void OnTriggerStay(Collider col)
	{
		if(col.CompareTag("ColorMonster"))
		{
			col.GetComponent<ColorMonster>().Hurt(shootScript.GetHurtValue());
		}
		else if(col.CompareTag("GreenMonster"))
		{
			col.GetComponent<GreenMonster>().Hurt(shootScript.GetHurtValue());
		}
		else if(col.CompareTag("CanBeHurt"))
		{
			col.GetComponent<CanBeHurt>().Hurt(shootScript.GetHurtValue());
		}
		else if(col.CompareTag("Operating"))
		{
			col.GetComponent<Operating>().Work();
		}
		else if(col.CompareTag("ColorTrap"))
		{
			col.GetComponent<ColorTrap>().Work();
		}
	}
}


}