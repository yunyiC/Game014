﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{



public class FirstPlayerController : MonoBehaviour {

	[Tooltip("复活点")] public Transform respawn;
	[Tooltip("移动速度")] public float moveSpeed = 5.0f;
	[Tooltip("奔跑速度")] public float runSpeed = 8.0f;
	[Tooltip("跳跃高度")] public float jumpSpeed = 5.0f;
	[Tooltip("血量上限")] public float bloodMax = 100;
	[Tooltip("死亡线高度")] public float DeadLine = -15;
	[Tooltip("死亡标记")] public bool isDead = false;

	public bool isInvincible = false;


	private CharacterController CC;
	// private SkillBoom skillBoom;
	// private Shoot shootScript;

	private UIPlayerBlood UIPBlood;
	private UIPlayerBuff UIPBuff;
	private UIDialogue UITip;
	private Camera mainCamera;
	private Vector3 directionT;//玩家方向
	private float gravity = 9.8f;
	private float turnSpeed = 2.0f;//玩家转向速度
	private float blood;//玩家当前血量
	private float camEularX;//玩家抬头角度
	private int poisonLevel;//中毒层数
	private int burnLevel;//燃烧层数
	private int burnTime;//燃烧持续时间
	private float timeT;//记录玩家一条命所坚持的时间
	private int respawnLevel;//复活进度

	
	void Awake()
	{
		respawn = GameObject.FindGameObjectWithTag("Respawn").transform;
		CC = this.GetComponent<CharacterController>();
		// skillBoom = this.GetComponent<SkillBoom>();
		// shootScript = this.GetComponent<Shoot>();
		mainCamera = Camera.main;
		blood = bloodMax;
		camEularX = 0;
		poisonLevel = 0;
		burnLevel = 0;
		burnTime = 0;
		respawnLevel = 0;
		timeT = Time.timeSinceLevelLoad;
		isInvincible = false;
	}
	void Start () {
		UIPBlood = UIManager.playerBloodUI;
		UIPBlood.SetbloodValue(blood, bloodMax);
		UIPBuff = UIManager.playerBuffUI;
		UIPBuff.SetPoison(poisonLevel);
		UIPBuff.SetBurn(burnLevel, burnTime);
		UITip = UIManager.dialogueUI;
	}
	
	void Update () {
		if(this.transform.position.y < DeadLine)
		{
			Dead();
		}
		else if(respawnLevel > 0)//复活中
		{
			if(respawnLevel < bloodMax * 0.5f)
			{
				UITip.SetDialogue("复活中。。。");
			}
			UIPBlood.SetbloodValue(bloodMax - respawnLevel, bloodMax);
			if(respawnLevel == 1)
			{
				Respawn();
			}
			respawnLevel --;
		}
		
		else if(!isDead)
		{
			Moving();
		}
		Looking();
		if(isInvincible)
		{
			blood = bloodMax;
		}
	}

	// void OnTriggerEnter(Collider col)
	// {
	// 	if(col.CompareTag("ColorTrap"))
	// 	{
	// 		col.GetComponent<ColorTrap>().Work2();
	// 	}
	// }
	private void Moving()
	{
		if(CC.isGrounded)
		{
			float speedT;
			if(Input.GetKey(KeyCode.LeftShift))
			{
				speedT = runSpeed;
			}
			else
			{
				speedT = moveSpeed;
			}
			directionT = transform.TransformDirection(
				new Vector3(Input.GetAxis("Horizontal"),0,Input.GetAxis("Vertical"))) * speedT;
			if(Input.GetKeyDown(KeyCode.Space))
			{
				directionT.y = jumpSpeed;
			}
		}
		directionT.y -= gravity * Time.deltaTime;
		CC.Move(directionT * Time.deltaTime);
	}
	private void Looking()
	{
		this.transform.Rotate(new Vector3(0f,Input.GetAxis("Mouse X")*turnSpeed,0f),Space.Self);
		float inputY = -Input.GetAxis("Mouse Y");
		if((inputY > 0 && camEularX + inputY < 90f) || (inputY < 0 && camEularX + inputY > -90f))
		{
			camEularX += inputY;
			mainCamera.transform.Rotate(new Vector3(inputY,0f,0f),Space.Self);
		}
	}
	

	public void Heal(int healValue)//治疗
	{
		UITip.SetDialogue("治疗:" + healValue + "。");
		blood += healValue;
		if(blood > bloodMax)
		{
			blood = bloodMax;
		}
		UIPBlood.SetbloodValue(blood, bloodMax);
		UIPBlood.SetBloodValueChange(Mathf.RoundToInt(healValue), true);
	}
	public void Clear()//净化
	{
		poisonLevel = 0;
		UIPBuff.SetPoison(poisonLevel);
		burnLevel = 0;
		burnTime = 0;
		UIPBuff.SetBurn(burnLevel, burnTime);
	}

	public void Hurt(float hurtValue)//受伤
	{
		if(hurtValue >= 1.0f)
		{
			UITip.SetDialogue("受伤:" + (int)hurtValue + "。");
		}
		if(hurtValue >= blood)
		{
			blood = 0;
			UIPBlood.SetbloodValue(blood, bloodMax);
			UIPBlood.SetBloodValueChange(blood, false);
			Dead();
		}
		else
		{
			blood -= hurtValue;
			UIPBlood.SetbloodValue(blood, bloodMax);
			UIPBlood.SetBloodValueChange(hurtValue,false);
		}
	}

	public void Repelled(Vector3 d)//被击退
	{
		d *= 1;
		d.y = 1.0f;
		CC.Move(d);
	}

	public void Poisoned(int level)//中毒
	{
		if(poisonLevel > 0)//若已中毒，按照中毒时间来
		{
			poisonLevel += level;
		}
		else//若未中毒，创建中毒时间钟
		{
			poisonLevel = level;
			Invoke("Poisoning",0.0f);
		}
	}

	private void Poisoning()//毒性发作中
	{
		if(poisonLevel > 0)
		{
			if(poisonLevel >= blood)
			{
				blood = 0;
				UIPBlood.SetbloodValue(0,bloodMax);
				UIPBlood.SetBloodValueChange(blood, false);
				UIPBuff.SetPoison(poisonLevel);
				Dead();
			}
			else
			{
				blood -= poisonLevel;
				UIPBlood.SetbloodValue(blood, bloodMax);
				UIPBlood.SetBloodValueChange(poisonLevel, false);
				UIPBuff.SetPoison(poisonLevel);
				poisonLevel--;
				Invoke("Poisoning",1.0f);
			}
		}
		else 
		{
			poisonLevel = 0;
			UIPBuff.SetPoison(poisonLevel);
		}
	}

	public void Burned(int level,int time)//燃烧
	{
		if(burnTime > 0)//若已燃烧，按照燃烧时间钟进行
		{
			burnTime += burnTime;
			if(burnLevel < level)//同种类型的伤害，取最高值
			{
				burnLevel = level;
			}
		}
		else//若未燃烧，创建燃烧时间钟
		{
			burnLevel = level;
			burnTime = time;
			Invoke("Burning",0.0f);
		}
	}

	private void Burning()//燃烧中
	{
		if(burnTime > 0)
		{
			if(burnLevel >= blood)
			{
				blood = 0;
				UIPBlood.SetbloodValue(blood, bloodMax);
				UIPBlood.SetBloodValueChange(blood, false);
				UIPBuff.SetBurn(burnLevel,burnTime);
				Dead();
			}
			else
			{
				blood -= burnLevel;
				UIPBlood.SetbloodValue(blood, bloodMax);
				UIPBlood.SetBloodValueChange(burnLevel, false);
				UIPBuff.SetBurn(burnLevel,burnTime);
				burnTime--;
				Invoke("Burning",1.0f);
			}
		}
		else
		{
			burnTime = 0;
			burnLevel = 0;
			UIPBuff.SetBurn(burnLevel,burnTime);
		}
	}

	public void Dead()//死亡
	{
		isDead = true;
		this.transform.position = respawn.position;
		float tT = Mathf.Round((Time.timeSinceLevelLoad - timeT) * 100)/100.0f;
		UITip.SetDialogue("存活时长: " + tT + "s 。");
		respawnLevel = Mathf.RoundToInt(bloodMax);
	}

	public void Respawn()//重生
	{
		UITip.SetDialogue("复活!。");
		this.transform.position = respawn.position;
		this.transform.eulerAngles = respawn.eulerAngles;
		blood = bloodMax;
		UIPBlood.SetbloodValue(blood, bloodMax);
		Clear();
		isDead = false;
		timeT = Time.timeSinceLevelLoad;
	}
	public void SetPlayerBloodMaxAdd(float value, bool isAdd)
	{
		bloodMax = isAdd ? bloodMax + value : bloodMax - value;
		blood = bloodMax;
		UIPBlood.SetbloodValue(blood, bloodMax);
	}
	public void SetPlayerBloodMax(float value)
	{
		if(value > 0.0f)
		{
			bloodMax = value;
			blood = bloodMax;
			UIPBlood.SetbloodValue(blood, bloodMax);
		}
	}
}



}
