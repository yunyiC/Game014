﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class SkillTurret : MonoBehaviour {

	[Tooltip("技能按键")] public KeyCode skillKey = KeyCode.E;
	[Tooltip("炮塔预置体")] public GameObject turretPrefab;
	[Tooltip("子弹预置体")] public GameObject boomPrefab;

	[Tooltip("技能冷却时间")] public float skillCoolLevelMax = 40.0f;
	[Tooltip("技能冷却剩余时间")] public float skillCoolLevel;
	[Tooltip("炮塔存活时间")] public float turretLiveTime = 20.0f;
	[Tooltip("爆炸技能伤害范围")] public float boomDistance = 10.0f;
	[Tooltip("爆炸技能伤害")] public float hurtValue = 100.0f;

	private UIPlayerSkills UISkill;
	private Transform playerTransform;
	private GameObject[] monsters;
	private Vector3 offsetT;

	void Awake()
	{
		skillCoolLevel = 0.0f;
	}
	void Start () {
		UISkill = UIManager.playerSkillsUI;
		UISkill.SetSkillA(skillCoolLevel, skillCoolLevelMax);
		playerTransform = GameManager.player.transform;
	}
	void Update () {
		Skilling();
	}
	private void Skilling()
	{
		if(skillCoolLevel >= 0.0f)
		{
			skillCoolLevel -= Time.deltaTime;
			UISkill.SetSkillA(skillCoolLevel, skillCoolLevelMax);
		}
		else if(Input.GetKeyDown(skillKey) && (GameManager.FPC.isDead == false))
		{
			Skill();
		}
		else
		{
			skillCoolLevel = 0.0f;
			UISkill.SetSkillA(skillCoolLevel, skillCoolLevelMax);
		}
	}
	private void Skill()
	{
		offsetT = playerTransform.forward * 3.0f + playerTransform.up * 1.0f;
		Boom();
		GameObject turretT = Instantiate(turretPrefab,playerTransform.position + offsetT,Quaternion.identity);
		Destroy(turretT,turretLiveTime);
		skillCoolLevel = skillCoolLevelMax;
		UISkill.SetSkillA(skillCoolLevel, skillCoolLevelMax);
	}
	public void Boom()
	{
		GameObject boomT = Instantiate(boomPrefab,playerTransform.position + offsetT,Quaternion.identity);
		monsters = GameObject.FindGameObjectsWithTag("ColorMonster");
		foreach(GameObject T in monsters)
		{
			if(Vector3.Distance(this.transform.position,T.transform.position) < boomDistance)
			{
				T.GetComponent<ColorMonster>().Hurt(hurtValue);
			}
		}
		monsters = GameObject.FindGameObjectsWithTag("GreenMonster");
		foreach(GameObject T in monsters)
		{
			if(Vector3.Distance(this.transform.position,T.transform.position) < boomDistance)
			{
				T.GetComponent<GreenMonster>().Hurt(hurtValue);
			}
		}
		Destroy(boomT,1.0f);
		monsters = GameObject.FindGameObjectsWithTag("CanBeHurt");
		foreach(GameObject T in monsters)
		{
			if(Vector3.Distance(this.transform.position,T.transform.position) < boomDistance)
			{
				T.GetComponent<CanBeHurt>().Hurt(hurtValue);
			}
		}
		Destroy(boomT,1.0f);
	}
}


}
