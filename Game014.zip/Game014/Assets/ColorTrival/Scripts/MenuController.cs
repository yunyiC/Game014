﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival
{


public class MenuController : MonoBehaviour {

	public KeyCode key = KeyCode.P;
	private Vector3 positionT;
	private Vector3 eularAngleT;
	private Transform menuCenter;
	void Start () {
		positionT = GameObject.FindGameObjectWithTag("Respawn").transform.position;
		eularAngleT = GameObject.FindGameObjectWithTag("Respawn").transform.eulerAngles;
		menuCenter = this.transform.Find("MenuPosition");
	}
	
	void Update () {
		if(Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(key))
		{
			float dT = Vector3.Distance(menuCenter.position,GameManager.player.transform.position);
			if(dT < 10)
			{
				Continue();
			}
			else
			{
				Pause();
			}
			
		}
	}

	void OnTriggerEnter(Collider col)
	{
		if(col.CompareTag("Player"))
		{
			Continue();
		}
	}
	public void Continue()
	{
		GameManager.player.transform.position = positionT;
		GameManager.player.transform.eulerAngles = eularAngleT;
	}
	public void Pause()
	{
		positionT = GameManager.player.transform.position;
		eularAngleT = GameManager.player.transform.eulerAngles;
		GameManager.player.transform.position = menuCenter.position;
		GameManager.player.transform.eulerAngles = menuCenter.eulerAngles;
	}
}


}

