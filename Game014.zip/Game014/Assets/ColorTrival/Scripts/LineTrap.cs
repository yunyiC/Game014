﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class LineTrap : MonoBehaviour
{
    public float hurtValue = 30;
    public Vector3 offset = new Vector3(0.0f, 5.0f, 0.0f);
    public float moveSpeed = 0.3f;

    private Vector3 positionA;
    private Vector3 positionB;
    private float moveLevel;
    void Awake() {
        positionA = this.transform.position;
        positionB = positionA + offset;
        moveLevel = 0.0f;
    }
    void Start () {
	}
	void Update () {
        moveLevel += moveSpeed * Time.deltaTime;
        this.transform.position = Vector3.Lerp(positionA, positionB, moveLevel);
        if(moveLevel >= 1.0f)
        {
            moveLevel = 0.0f;
            Vector3 T = positionA;
            positionA = positionB;
            positionB = T;
        }
	}
    private void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Player")
        {
            GameManager.FPC.Hurt(hurtValue);
        }
        else if (col.CompareTag("GreenMonster"))
        {
            col.GetComponent<GreenMonster>().Hurt(hurtValue);
        }
    }
}

}
