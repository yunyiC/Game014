﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class TextBloodDown : MonoBehaviour {
	
	public Vector3 speedV3 = new Vector3(0.0f, 5.0f, 0.0f);
	public float gravity = 9.8f;
	public float deadLine = -15.0f;

	private Transform playerTrans;

	void Awake()
	{
	}
	void Start () {
		playerTrans = GameManager.player.transform;
	}
	void Update () {
		if(this.transform.position.y <= deadLine)
		{
			Destroy(this.gameObject, 0.0f);
		}
		this.transform.eulerAngles = playerTrans.eulerAngles;
		speedV3.y -= gravity * Time.deltaTime;
		this.transform.position += speedV3 * Time.deltaTime;
	}
}


}
