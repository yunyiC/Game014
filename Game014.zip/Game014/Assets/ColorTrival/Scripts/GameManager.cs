﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ColorTrival{



public class GameManager : MonoBehaviour {
	public static GameObject player;
	public static FirstPlayerController FPC;
	public static UIManager UI;
	public static MenuController MENU;


	public static int playerGold;


	void Awake()
	{
		player = GameObject.FindGameObjectWithTag("Player");
		FPC = player.GetComponent<FirstPlayerController>();
		UI = GameObject.Find("UI").GetComponent<UIManager>();
		MENU = GameObject.FindGameObjectWithTag("Menu").GetComponent<MenuController>();

		playerGold = 0;
		
	}
	void Start () {
	}
	void Update () {
	}

	public static void LoadScene(string sceneName)
	{
		SceneManager.LoadScene(sceneName);
	}
	public static void Quit()
	{
		Application.Quit();
		Debug.Log("退出游戏。");
	}


}
}
