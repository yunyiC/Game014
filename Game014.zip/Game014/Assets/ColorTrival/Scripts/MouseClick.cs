﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MouseClick : MonoBehaviour
{
    public GameObject objTest;
    public bool isShow = true;


    float distance = float.MaxValue;
    public LayerMask layerMask;

    void Awake()
    {
        
    }

    void Start()
    {
        
    }

    void Update()
    {
        Check();

        if (Input.GetKeyDown(KeyCode.Tab))
        {
            isShow = !isShow;
            objTest.SetActive(isShow);
        }
    }

    void LateUpdate()
    {
        
    }

    void FixedUpdate()
    {
        
    }

    private void Check()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hitInfo;
            if (Physics.Raycast(ray, out hitInfo, distance, layerMask))
            {
                transform.position = hitInfo.point;
                Debug.DrawLine(Camera.main.transform.position, hitInfo.point, Color.red);
            }
        }
    }
}
