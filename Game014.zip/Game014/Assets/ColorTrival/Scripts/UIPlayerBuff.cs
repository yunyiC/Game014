﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UIPlayerBuff : MonoBehaviour {
	
	[Tooltip("中毒初始颜色")] public Color colorPoisonStart;//
	[Tooltip("中毒最终颜色")] public Color colorPoisonEnd;//
	[Tooltip("燃烧初始颜色")] public Color colorBurnStart;//
	[Tooltip("燃烧最终颜色")] public Color colorBurnEnd;//
	[Tooltip("中毒")] public Text txtPoison;//
	[Tooltip("燃烧")] public Text txtBurn;//
	[Tooltip("中毒文字显示时间(s)")] public float tColorPoisonLevelMax = 5.0f;//
	[Tooltip("中毒文字剩余显示时间(s)")] public float tColorPoisonLevel;//
	[Tooltip("燃烧文字显示时间(s)")] public float tColorBurnLevelMax = 5.0f;//
	[Tooltip("燃烧文字剩余显示时间(s)")] public float tColorBurnLevel;//
	

	void Awake() {
	}
	void Start () {
	}
	void Update () {
		Lightening();
	}

	private void Lightening()//字体的颜色会慢慢变淡
	{
		if(tColorPoisonLevel > 0.0f)//中毒文字变化显示
		{
			txtPoison.color = Color.Lerp( colorPoisonEnd, colorPoisonStart, tColorPoisonLevel / tColorPoisonLevelMax );
			tColorPoisonLevel -= Time.deltaTime;
		}
		else
		{
			txtPoison.color = colorPoisonEnd;
			tColorPoisonLevel = 0.0f;
		}

		if(tColorBurnLevel > 0.0f)//燃烧文字变化显示
		{
			txtBurn.color = Color.Lerp( colorBurnEnd, colorBurnStart, tColorBurnLevel / tColorBurnLevelMax );
			tColorBurnLevel -= Time.deltaTime;
		}
		else
		{
			txtBurn.color = colorBurnEnd;
			tColorBurnLevel = 0.0f;
		}
	}
	public void SetPoison(int value)
	{
		if(value > 0)
		{
			txtPoison.text = "中毒:" + value + "!";
			tColorPoisonLevel = tColorPoisonLevelMax;
		}
		else
		{
			txtPoison.text = "";
			tColorPoisonLevel = 0;
		}
	}
	public void SetBurn(int value,int time)
	{
		
		if((value > 0) && (time > 0))
		{
			txtBurn.text = "燃烧:" + value + "(×" + time + ")";
			tColorBurnLevel = tColorBurnLevelMax;
		}
		else
		{
			txtBurn.text = "";
			tColorBurnLevel = 0;
		}
	}
}


}
