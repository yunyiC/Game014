﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{



public class CusorController : MonoBehaviour {

	public KeyCode key = KeyCode.T;
	void Start () {
		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;
	}
	void Update () {
		if(Input.GetKeyDown(key))
		{
			if(Cursor.visible == false)
			{
				Cursor.lockState = CursorLockMode.None;
				Cursor.visible = true;
			}
			else
			{
				Cursor.lockState = CursorLockMode.Locked;
				Cursor.visible = false;
			}	
		}
	}



}
}
