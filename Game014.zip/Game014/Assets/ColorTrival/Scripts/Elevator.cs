﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class Elevator : MonoBehaviour {
	public Transform target;
	public Vector3[] offset;
	public float leftTimeMax = 3.0f;
	public bool isWork = true;

	private int i;
	private float leftTimeNow;
	private Vector3 positionT;
	void Awake()
	{
		i = 0;
		leftTimeNow = leftTimeMax;
		positionT = target.transform.position;
		if(target == null)
		{
			target = this.transform;
		}
	}
	void Start () {
		
	}
	void Update () {
		if(isWork)
		{
			if(leftTimeNow > 0)
			{
				target.transform.position = Vector3.Lerp(positionT+offset[i],positionT,(float)leftTimeNow/leftTimeMax); 
				leftTimeNow -= Time.deltaTime;
			}
			else
			{
				positionT = target.transform.position;
				i++;
				if(i >= offset.Length)
				{
					i = 0;
				}
				leftTimeNow = leftTimeMax;
			}
		}
	}
	void OnTriggerEnter(Collider col)
	{
		if(col.CompareTag("Player"))
		{
			col.transform.SetParent(target);
		}
	}
	void OnTriggerExit(Collider col)
	{
		if(col.CompareTag("Player"))
		{
			col.transform.SetParent(null);
		}
	}


	
}
}
