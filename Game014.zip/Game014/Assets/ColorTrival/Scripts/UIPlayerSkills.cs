﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UIPlayerSkills : MonoBehaviour {

	[Tooltip("技能A遮罩")] public Image maskSkillA;//
	[Tooltip("技能A文本")] public Text txtSkillA;//
	[Tooltip("技能B遮罩")] public Image maskSkillB;//
	[Tooltip("技能B文本")] public Text txtSkillB;//
	

	void Awake() {
	}
	void Start () {
	}
	void Update () {
	}
	public void SetSkillA(float tCoolLevel, float tCoolLevelMax)
	{
		
		if(tCoolLevel > 0 && tCoolLevelMax > 0)
		{
			maskSkillA.fillAmount = tCoolLevel / tCoolLevelMax;
			txtSkillA.text = (Mathf.Round(tCoolLevel * 10) / 10.0f).ToString();
		}
		else
		{
			maskSkillA.fillAmount = 0.0f;
			txtSkillA.text = "E";
		}
	}
	public void SetSkillB(float tCoolLevel, float tCoolLevelMax)
	{
		if(tCoolLevel > 0 && tCoolLevelMax > 0)
		{
			maskSkillB.fillAmount = tCoolLevel / tCoolLevelMax;
			txtSkillB.text = (Mathf.Round(tCoolLevel * 10) / 10.0f).ToString();
		}
		else
		{
			maskSkillB.fillAmount = 0.0f;
			txtSkillB.text = "F";
		}
	}
}


}
