﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class Tips : MonoBehaviour {

	[Tooltip("提示词")] public string tip;
	[Tooltip("一次性？")] public bool isOnce = false;

	private UIDialogue UITip;
	void Start () {
		UITip = UIManager.dialogueUI;
	}
	void Update () {
		
	}
	void OnTriggerEnter(Collider col)
	{
		if(col.CompareTag("Player"))
		{
			UITip.SetDialogue(tip);
			if(isOnce)
			{
				Destroy(this.gameObject,0.0f);
			}
		}
	}
}


}
