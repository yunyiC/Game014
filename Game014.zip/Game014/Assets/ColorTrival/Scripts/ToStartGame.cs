﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class ToStartGame : MonoBehaviour {
	public bool isWork = false;
	public string strWelcome;
	public Vector3 upSpeedV3 = new Vector3(0.0f, 20.0f, 0.0f);
	public float stopLine = 0.0f;

	private float deadLineT = -15.0f;

	void Start () {
		deadLineT = GameManager.FPC.DeadLine;
		GameManager.FPC.DeadLine = -1000.0f;
		GameManager.player.transform.position = this.transform.position + new Vector3(0,2,0);
		GameManager.player.transform.eulerAngles = this.transform.eulerAngles;
	}
	void Update () {
		if(isWork)
		{
			this.transform.position += upSpeedV3 * Time.deltaTime;
			if(this.transform.position.y >= stopLine)
			{
				isWork = false;
				GameManager.FPC.DeadLine = deadLineT;
				GameManager.FPC.isDead = false;
				UIManager.dialogueUI.SetDialogue(strWelcome);
			}
		}
	}

	void OnTriggerEnter(Collider col)
		{
			if(col.CompareTag("Player"))
			{
				col.transform.SetParent(this.transform);
				col.GetComponent<FirstPlayerController>().isDead = true;
				isWork = true;
			}
		}
	}

}
