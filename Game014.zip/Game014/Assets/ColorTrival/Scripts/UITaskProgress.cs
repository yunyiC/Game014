﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UITaskProgress : MonoBehaviour {

	public Text txtTaskProgress;
	public int taskProgressMax;

	private int taskProgress;
	void Awake()
	{
		taskProgress = 0;
		txtTaskProgress.text = taskProgress + "/" + taskProgressMax;
	}

	void Start () {
		
	}
	void Update () {
		
	}
	public void TaskProgressAdd()
	{
		taskProgress ++;
		if(taskProgress >= taskProgressMax)
		{
			TaskDone();
		}
		else
		{
			txtTaskProgress.text = taskProgress + "/" + taskProgressMax;
		}
	}

	private void TaskDone()
	{
		UIManager.dialogueUI.SetDialogue("你成功了！");
		txtTaskProgress.text = "完成";
	}
}

}
