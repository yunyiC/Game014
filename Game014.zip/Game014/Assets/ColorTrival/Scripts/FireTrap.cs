﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class FireTrap : MonoBehaviour {
    public GameObject fireBallPrefab;
    [Tooltip("火焰开启时间")] public float openTime = 5;
    [Tooltip("火焰关闭时间")] public float closeTime = 3;
    void Start() {
        open();
    }
    void Update() {

    }
    private void open()
    {
        fireBallPrefab.SetActive(true);
        Invoke("close", openTime);
    }
    private void close()
    {
        fireBallPrefab.SetActive(false);
        Invoke("open", closeTime);
    }
}

}
