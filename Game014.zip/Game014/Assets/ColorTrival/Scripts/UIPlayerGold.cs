﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UIPlayerGold : MonoBehaviour {
	
	[Tooltip("金币数量变化初始颜色")] public Color colorStart;//
	[Tooltip("金币数量变化最终颜色")] public Color colorEnd;//
	[Tooltip("金币数量")] public Text txtGoldValue;//
	[Tooltip("金币数量变化")] public Text txtGoldValueChange;//
	[Tooltip("金币数量变化显示时间(s)")] public float tGoldValueChangeLevelMax = 5.0f;//
	[Tooltip("金币数量变化剩余显示时间(s)")] public float tGoldValueChangeLevel;//
	

	void Awake() {
	}
	void Start () {
	}
	void Update () {
		Lightening();
	}

	private void Lightening()//字体的颜色会慢慢变淡
	{
		if(tGoldValueChangeLevel > 0.0f)//血量变化显示
		{
			txtGoldValueChange.color =
				Color.Lerp(colorEnd, colorStart, tGoldValueChangeLevel / tGoldValueChangeLevelMax );
			tGoldValueChangeLevel -= Time.deltaTime;
		}
		else
		{
			txtGoldValueChange.color = colorEnd;
			tGoldValueChangeLevel = 0.0f;
		}
	}
	public void SetGoldValueChange(int value, bool isAdd)
	{
		GameManager.playerGold = isAdd ? (GameManager.playerGold + value) : (GameManager.playerGold - value);
		txtGoldValue.text = "金币:" + GameManager.playerGold;
		txtGoldValueChange.text = isAdd ? "+" + value.ToString() : "-" + value.ToString();
		tGoldValueChangeLevel = tGoldValueChangeLevelMax;
	}
}


}
