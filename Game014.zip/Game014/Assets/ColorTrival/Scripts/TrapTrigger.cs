﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{



public class TrapTrigger : MonoBehaviour {

	public GameObject target;

	private int timeT = 60;
	void Awake()
	{
	}

	void OnTriggerStay(Collider col)//玩家站在里面，一秒工作一次
	{
		if(col.CompareTag("Player"))
		{
			timeT ++;
			if(timeT >= 60)
			{
				Work();
				timeT = 0;
			}
		}
	}
	void OnTriggerExit(Collider col)//玩家站在里面，一秒工作一次
	{
		if(col.CompareTag("Player"))
		{
			Leave();
		}
	}
	private void Work()
	{
		if(target.CompareTag("ColorTrapDown"))
		{
			target.GetComponent<ColorTrapDown>().Work();
		}
	}
	private void Leave()
	{
		if(target.CompareTag("ColorTrapDown"))
		{
			target.GetComponent<ColorTrapDown>().Leave();
		}
	}
}


}
