﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class FireAreaTrap : MonoBehaviour
{
    public int hurtLevel = 5;
    public int hurtTime = 3;
    public float coolLevelMax = 2.0f;

    private float coolLevel;
    void Awake()
    {
        coolLevel = 0.0f;
    }
    void Start() {

    }
    void Update() {
        if(coolLevel > 0.0f)
        {
            coolLevel -= Time.deltaTime;
        }
    }
    private void OnTriggerStay(Collider col)
    {
        if (col.CompareTag("Player") && coolLevel <= 0.0f)
        {
            GameManager.FPC.Burned(hurtLevel, hurtTime);
            coolLevel = coolLevelMax;
        }
        else if (col.CompareTag("GreenMonster"))
        {
            col.GetComponent<GreenMonster>().Hurt(hurtLevel / 30.0f);
        }
    }
}


}
