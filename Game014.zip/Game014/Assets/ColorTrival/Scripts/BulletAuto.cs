﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletAuto : MonoBehaviour {

	private float flySpeed = 50.0f;
	private float flyTime = 3.0f;
	void Start () {
		Destroy(this.gameObject,flyTime);
	}
	void Update () {
		this.transform.position += this.transform.forward*flySpeed*Time.deltaTime;
	}
}
