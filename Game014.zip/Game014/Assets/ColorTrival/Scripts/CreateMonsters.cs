﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{
public class CreateMonsters : MonoBehaviour {
	public Transform[] monsterHomes;
	public GameObject monsterPrefab;
	void Awake()
	{
	}
	void Start () {
		
	}
	void Update () {
		
	}
	void OnTriggerEnter(Collider col)
	{
		if(col.gameObject.CompareTag("Player"))
		{
			foreach(Transform T in monsterHomes)
			{
				Instantiate(monsterPrefab,T.position,Quaternion.identity);
			}
			Destroy(this.gameObject,0.0f);
		}
	}
}

}
