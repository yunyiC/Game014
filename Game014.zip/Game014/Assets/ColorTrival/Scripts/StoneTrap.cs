﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class StoneTrap : MonoBehaviour {
    public GameObject stonePrefab;
    public Transform stoneRespawn;
    public float coolLevelMax = 10.0f;

    private float coolLevel;
    void Awake()
    {
        coolLevel = 0.0f;
    }
	void Start () {
	}
	void Update () {
        if(coolLevel > 0.0f)
        {
            coolLevel -= Time.deltaTime;
        }
	}
    private void OnTriggerEnter(Collider col)
    {
        if (col.CompareTag("Player") && coolLevel <= 0.0f)
        {
            Instantiate(stonePrefab, stoneRespawn.position, Quaternion.identity);
            coolLevel = coolLevelMax;
        }
    }
}


}
