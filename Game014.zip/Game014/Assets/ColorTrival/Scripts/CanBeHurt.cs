﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{



public class CanBeHurt : MonoBehaviour {
	public bool isOnly = true;
	public int bloodMax = 100;
	public float blood;

	void Awake()
	{
		blood = bloodMax;
	}
	void Start () {
	}
	void Update () {
		
	}
	// void OnTriggerEnter(Collider col)
	// {
	// 	if(col.CompareTag("Bullet"))
	// 	{
	// 		Hurt(GameManager.FPC.hurtValue);
	// 	}
	// }
	public void Hurt(float hurtValue)
	{
		if(hurtValue >= blood)
		{
			blood = 0;
			UIManager.playerGoldUI.SetGoldValueChange(bloodMax, true);
			if(!isOnly && transform.parent != null)
			{
				GameObject.Destroy(transform.parent.gameObject,0.0f);
			}
			CreateMonster();
			GameObject.Destroy(this.gameObject,0.0f);
		}
		else
		{
			blood -= hurtValue;
			// UIManager.secondBloodUI.SetBloodValueChange(hurtValue, true);
		}
	}

	private void CreateMonster()
	{
		
	}


}	
}
