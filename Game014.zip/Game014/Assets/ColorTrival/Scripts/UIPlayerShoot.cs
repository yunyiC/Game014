﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UIPlayerShoot : MonoBehaviour {
	
	[Tooltip("射击冷却进度条")] public Slider sldShootCool;//
	[Tooltip("射击类型图片区A")] public Image imgA;//
	[Tooltip("射击类型图片区B")] public Image imgB;//
	[Tooltip("射击类型图片区C")] public Image imgC;//
	[Tooltip("射击类型图片子弹")] public Sprite sprBullet;
	[Tooltip("射击类型图片激光")] public Sprite sprLaser;
	[Tooltip("射击类型图片燃烧")] public Sprite sprFire;
	[Tooltip("攻击类型文本")] public Text txtshootType;//
	[Tooltip("攻击力文本")] public Text txtHurtValue;//
	[Tooltip("射击冷却显示值")] public Text txtShootCool;//

	void Awake() {
	}
	void Start () {
	}
	void Update () {
		
	}

	public void SetShootSlider(float level, float levelMax)
	{
		if(levelMax > 0.0f && levelMax > 0.0f)
		{
			sldShootCool.maxValue = levelMax;
			sldShootCool.value = level;
			txtShootCool.text = Mathf.RoundToInt(level).ToString();
		}
		else
		{
			sldShootCool.value = 0.0f;
			txtShootCool.text = "";
		}
	}
	public void SetShootType(ShootType shootType, float hurtValue )
	{
		
		switch(shootType)
		{
			case ShootType.Bullet :
				txtshootType.text = "子弹";
				txtHurtValue.text = "攻击力:" + (int)hurtValue;
				imgA.sprite = sprBullet;
				imgB.sprite = sprLaser;
				imgC.sprite = sprFire;
				break;
			case ShootType.Laser :
				txtshootType.text = "激光";
				txtHurtValue.text = "攻击力:" + (int)(hurtValue * 10);
				imgA.sprite = sprLaser;
				imgB.sprite = sprFire;
				imgC.sprite = sprBullet;
				break;
			case ShootType.Fire :
				txtshootType.text = "火焰";
				txtHurtValue.text = "攻击力:" + (int)(hurtValue * 10);
				imgA.sprite = sprFire;
				imgB.sprite = sprBullet;
				imgC.sprite = sprLaser;
				break;
			default:break;
		}
	}
}


}
