﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class Stone : MonoBehaviour {
    public float hurtValue = 30.0f;
    public float deadLine = -15.0f;

	void Start () {
	}
	void Update () {
        if(this.transform.position.y <= deadLine)
        {
            Destroy(this.gameObject,0.0f);
        }
	}
    private void OnTriggerEnter(Collider col)
    {
        if (col.CompareTag("Player"))
        {
           GameManager.FPC.Hurt(hurtValue);
        }
    }
}
}
