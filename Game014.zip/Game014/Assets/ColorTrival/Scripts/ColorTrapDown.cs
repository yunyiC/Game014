﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{



public class ColorTrapDown : MonoBehaviour {
	public TrapColor colorNow = TrapColor.White;
	public int bloodMax = 3;
	public int blood;
	public float respawnTime = 5.0f;

	private int rand;
	private Transform respawnTransT;
	void Awake()
	{
		blood = bloodMax;
		respawnTransT = GameObject.FindGameObjectWithTag("Respawn").transform;
	}
	void Start()
	{
	}
	void Update()
	{
		
	}

	// void OnTriggerStay(Collider col)
	// {
	// 	if(col.CompareTag("Player"))
	// 	{
	// 		timeT ++;
	// 		if(timeT >= 60)
	// 		{
	// 			Work();
	// 			timeT = 0;
	// 		}
	// 	}
	// }

	public void Work()
	{
		rand = Random.Range(0,100);
		// Debug.Log("随机数:" + rand);
		Hurt();
		switch(colorNow)
		{
			case TrapColor.Red:RedTrap();break;
			case TrapColor.Orange:OrangeTrap();break;
			case TrapColor.Blue:BlueTrap();break;
			case TrapColor.Green:GreenTrap();break;
			case TrapColor.Purple:PurpleTrap();break;
			case TrapColor.Black:BlackTrap();break;
			case TrapColor.White:WhiteTrap();break;
			default:break;
		}
	}

	public void Leave()
	{

	}

	private void Hurt()//被射击或者被触发时损失耐久
	{
		blood--;
		if(blood <= 0)
		{
			this.gameObject.SetActive(false);
			Invoke("Respawn",respawnTime);
			// Destroy(this.gameObject,0.5f);
		}
	}

	private void Respawn()//恢复
	{
		blood = bloodMax;
		this.gameObject.SetActive(true);
	}

	private void RedTrap()//红
	{
		if(rand < 80)
		{
			int healValue = 50;
			GameManager.FPC.Heal(healValue);
		}
		else
		{
			int hurtValue = 50;
			GameManager.FPC.Hurt(hurtValue);
		}
	}
	private void OrangeTrap()//橘
	{
		int burnLevel = 3,burnTime = 3;
		GameManager.FPC.Burned(burnLevel,burnTime);

	}
	private void BlueTrap()//蓝
	{
		// if(blood == (bloodMax - 2))
		// {
		// 	blood = 1;
		// 	Hurt();
		// }
	}
	private void GreenTrap()//绿
	{
			int poisonLevel = 3;
			GameManager.FPC.Poisoned(poisonLevel);
	}
	private void PurpleTrap()//紫
	{
		GameManager.FPC.isInvincible = true;
	}
	private void BlackTrap()//黑
	{
		blood = bloodMax;
		if (Vector3.Distance(respawnTransT.position, this.transform.position) > 10.0f)
		{
			respawnTransT.position = this.transform.position + new Vector3(0.0f,2.0f,0.0f);
			UIManager.dialogueUI.SetDialogue("复活点已保存。");
		}
	}

	private void WhiteTrap()//白
	{
		//回主菜单
		if(blood == 0)
		{
			BackToMenu();
		}
	}
	private void BackToMenu()
	{
		GameManager.MENU.Pause();
	}



}
}




