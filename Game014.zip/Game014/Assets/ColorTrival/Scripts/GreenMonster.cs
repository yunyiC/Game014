﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class GreenMonster : MonoBehaviour {

	[Header("观测值:")]
	[Tooltip("当前状态。")] public MonsterState stateNow;
	[Tooltip("临时目标。")] public Vector3 targetV3;
	[Tooltip("僵尸耳朵标记。")] public GameObject ear;
	[Tooltip("僵尸耳朵标记红色。")] public Color earColorA;
	[Tooltip("僵尸耳朵标记白色。")] public Color earColorB;
	[Tooltip("与目标的距离。")] public float distanceT;
	[Tooltip("目标标记")] public Transform targetMark;
	[Tooltip("血量。")] public float blood;
	[Tooltip("停留时间。")] public int stayTimes = 0;
	[Tooltip("跟踪耐心。")] public int patientLevel;
	[Tooltip("攻击后的冷却的剩余时间。")] public float attackCoolLevel;


	[Header("属性值:")]
	[Tooltip("死亡高度。")] public float deadLine = -15.0f;
	[Tooltip("死亡距离。")] public float deadDistance = 60.0f;
	[Tooltip("攻击时追踪敌人的速度。")] public float attackSpeed = 5.0f;
	[Tooltip("追赶时追踪敌人的速度。")] public float trackSpeed = 7.0f;
	[Tooltip("巡逻时追踪敌人的速度。")] public float patrolSpeed = 3.0f;
	[Tooltip("攻击后追踪敌人的速度。")] public float waitSpeed = 0.0f;
	[Tooltip("感知半径。")] public float feelRadius = 10.0f;
	[Tooltip("活动半径。")] public float patrolRadius = 20.0f;
	[Tooltip("攻击半径。")] public float attackRadius = 2.0f;
	[Tooltip("攻击伤害。")] public float hurtValue = 10.5f;
	[Tooltip("攻击冷却时间。")] public float attackCoolDown = 3.0f;
	[Tooltip("血量上限。")] public float bloodMax = 100.0f;

	private CharacterController CC;
	private float gravity = 9.8f;
	private Vector3 moveDirectionT;
	private UISecondBlood UISecBlood;
	private UIPlayerGold UIGold;
	private Transform playerTransform;//用于实时获取玩家的位置
	private int patientLevelMax;//跟踪耐心上限
	private Vector3 lastPositionT;//记录上一帧的位置，避免停留某处太久。

	void Awake()
	{
		CC = this.GetComponent<CharacterController>();
		patientLevelMax = 200;
		patientLevel = 0;
		attackCoolLevel = 0.0f;
		blood = bloodMax;
		lastPositionT = this.transform.position;
	}
	void Start()
	{
		UISecBlood = UIManager.secondBloodUI;
		UIGold = UIManager.playerGoldUI;
		playerTransform = GameManager.player.transform;
		targetV3 = this.transform.position;
		if(targetMark != null)
		{
			targetMark.position = targetV3;
		}

		distanceT = Vector3.Distance(this.transform.position,playerTransform.position);
		if(distanceT <= feelRadius)
		{
			stateNow = MonsterState.Attacking;
			ear.GetComponent<MeshRenderer>().material.color = earColorA;
		}
		else
		{
			stateNow = MonsterState.Patroling;
			ear.GetComponent<MeshRenderer>().material.color = earColorB;
		}
	}
	void Update()
	{
		if(this.transform.position.y < deadLine)
		{
			Destroy(this.gameObject,0.0f);
		}
		else
		{
			// this.transform.eulerAngles = new Vector3(0.0f, this.transform.eulerAngles.y, 0.0f);

			distanceT = Vector3.Distance(this.transform.position,playerTransform.position);
			if(distanceT > deadDistance)
			{
				Destroy(this.gameObject,0.0f);
			}
			else
			{
				switch(stateNow)
				{
					case MonsterState.Attacking:Attacking();break;
					case MonsterState.Tracking:Tracking();break;
					case MonsterState.Patroling:Patroling();break;
					case MonsterState.Waiting:Waiting();break;
					default:break;
				}
			}
			
		}
	}

	public void Hurt(float hurtValue)
	{
		if(hurtValue >= blood)
		{
			// UISecBlood.SetBloodValueChange(blood, false);
			UIGold.SetGoldValueChange(Mathf.RoundToInt(bloodMax), true);//玩家金币加
			Destroy(this.gameObject,0.0f);
		}
		else
		{
			blood -= hurtValue;
			UISecBlood.SetbloodValue(blood, bloodMax);
			// UISecBlood.SetBloodValueChange(hurtValue,false);
			if(attackCoolLevel > 0)
			{
			}
			else
			{
				patientLevel = patientLevelMax;
				stateNow = MonsterState.Tracking;
				ear.GetComponent<MeshRenderer>().material.color = earColorA;
			}
		}
	}

	public void Repelled(Vector3 d)//被击退
	{
		CC.Move(d);
	}
	private void Attacking()//攻击
	{
		if(distanceT >= feelRadius)
		{
			stateNow = MonsterState.Tracking;
		}
		else
		{
			// NMA.SetDestination(playerTransform.position);
			Vector3 pointT = new Vector3(playerTransform.position.x,this.transform.position.y,playerTransform.position.z);
			this.transform.LookAt(pointT);
			moveDirectionT = this.transform.forward * attackSpeed * Time.deltaTime;
			moveDirectionT.y -= gravity;
			CC.Move(moveDirectionT);
			// this.transform.Translate(moveDirectionT);
			if(targetMark != null)
			{
				targetMark.position = playerTransform.position;
			}
			patientLevel = patientLevelMax;
			if((attackCoolLevel <= 0.0f) && (distanceT <= attackRadius) && (GameManager.FPC.isDead == false))
			{
				Attack();
			}
		}
	}
	private void Tracking()//追踪
	{
		if(distanceT < feelRadius)
		{
			stateNow = MonsterState.Attacking;
		}
		else
		{
			if(patientLevel < 0)
			{
				stateNow = MonsterState.Patroling;
				ear.GetComponent<MeshRenderer>().material.color = earColorB;
			}
			else
			{
				patientLevel--;
				// NMA.SetDestination(playerTransform.position);
				Vector3 pointT = new Vector3(playerTransform.position.x,this.transform.position.y,playerTransform.position.z);
				this.transform.LookAt(pointT);
				moveDirectionT = this.transform.forward * trackSpeed * Time.deltaTime;
				moveDirectionT.y -= gravity;
				CC.Move(moveDirectionT);
				// this.transform.Translate(moveDirectionT);
				if(targetMark != null)
				{
					targetMark.position = playerTransform.position;
				}
			}
		}
	}

	private void Patroling()//巡逻
	{
		if(distanceT < feelRadius)
		{
			stateNow = MonsterState.Attacking;
			ear.GetComponent<MeshRenderer>().material.color = earColorA;
		}
		else
		{
			Vector3 offset;
			// NMA.SetDestination(targetV3);
			this.transform.LookAt(targetV3);
			moveDirectionT = this.transform.forward * patrolSpeed * Time.deltaTime;
			moveDirectionT.y -= gravity;
			CC.Move(moveDirectionT);
			// this.transform.Translate(moveDirectionT);
			
			if(targetMark != null)
			{
				targetMark.position = targetV3;
			}

			distanceT = Vector3.Distance(this.transform.position,targetV3);
			if(distanceT > attackRadius)
			{
				//继续追临时目标
			}
			else
			{//追到了临时目标
				offset = new Vector3(Random.Range(-patrolRadius,patrolRadius),0.0f, Random.Range(-patrolRadius,patrolRadius) );
				targetV3 = this.transform.position + offset;
				// NMA.SetDestination(targetV3);//建立新的目标点
				if(targetMark != null)
				{
					targetMark.position = targetV3;
				}
			}
			
			
			distanceT = Vector3.Distance(this.transform.position,lastPositionT);
			// Debug.Log(distanceT + "");
			lastPositionT = this.transform.position;
			if(distanceT < 0.06f)
			{
				stayTimes++; 
			}
			else
			{
				stayTimes = 0;
			}
			if(stayTimes > 200)
			{
				stayTimes = 0;
				offset = new Vector3(Random.Range(-patrolRadius,patrolRadius),0.0f, Random.Range(-patrolRadius,patrolRadius) );
				targetV3 = this.transform.position + offset;
			}
		}	
	}
	private void Waiting()//攻击之后的恢复
	{
		if(attackCoolLevel > 0)
		{
			attackCoolLevel -= Time.deltaTime;
			this.transform.Rotate(0.0f,1.0f,0.0f);
		}
		else
		{
			// stateNow = MonsterState.Patroling;
			distanceT = Vector3.Distance(this.transform.position,playerTransform.position);
			if(distanceT <= feelRadius)
			{
				stateNow = MonsterState.Attacking;
				ear.GetComponent<MeshRenderer>().material.color = earColorA;
			}
			else
			{
				stateNow = MonsterState.Patroling;
				ear.GetComponent<MeshRenderer>().material.color = earColorB;
			}
		}
	}
	private void Attack()
	{
		GameManager.FPC.Hurt(hurtValue);
		GameManager.FPC.Repelled(playerTransform.position - this.transform.position);
		attackCoolLevel = attackCoolDown;
		patientLevel = 0;
		
		stateNow = MonsterState.Waiting;
		ear.GetComponent<MeshRenderer>().material.color = earColorB;
	}


}
}