﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UISecondBlood : MonoBehaviour {
	
	// [Tooltip("血量变化初始颜色")] public Color colorStart;//
	// [Tooltip("血量变化最终颜色")] public Color colorEnd;//
	[Tooltip("血量进度条")] public Slider sldBlood;//
	[Tooltip("血量")] public Text txtBloodValue;//
	// [Tooltip("血量变化")] public Text txtBloodValueChange;//
	// [Tooltip("血量变化显示时间(s)")] public float tBloodValueChangeLevelMax = 3.0f;//
	// [Tooltip("血量变化剩余显示时间(s)")] public float tBloodValueChangeLevel;//

	void Awake() {
	}
	void Start () {
	}
	void Update () {
		// Lightening();
	}

	// private void Lightening()//字体的颜色会慢慢变淡
	// {
	// 	if(tBloodValueChangeLevel > 0.0f)//血量变化显示
	// 	{
	// 		txtBloodValueChange.color = Color.Lerp(colorEnd, colorStart, tBloodValueChangeLevel / tBloodValueChangeLevelMax );
	// 		tBloodValueChangeLevel -= Time.deltaTime;
	// 	}
	// 	else
	// 	{
	// 		txtBloodValueChange.color = colorEnd;
	// 		tBloodValueChangeLevel = 0.0f;
	// 	}
	// }
	public void SetbloodValue(float blood, float bloodMax)//设置血量条的值
	{
		sldBlood.maxValue = bloodMax;
		sldBlood.value = blood;
		txtBloodValue.text = (int)blood + "/" + (int)bloodMax;
	}

	// public void SetBloodValueChange(int value, bool isAdd)
	// {
	// 	txtBloodValueChange.text = isAdd ? "+" + value.ToString() : "-" + value.ToString();
	// 	tBloodValueChangeLevel = tBloodValueChangeLevelMax;
	// }
}


}
