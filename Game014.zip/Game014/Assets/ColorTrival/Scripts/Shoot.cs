﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public enum ShootType{
	Bullet = 1,
	Laser = 2,
	Fire = 3,
}


public class Shoot : MonoBehaviour {

	[Header("观测值")]
	[Tooltip("射击类型")] public ShootType shootType = ShootType.Bullet;
	public float bloodDownNum;
	public int bloodDownTimeMax = 60;
	public int bloodDownTime;


	[Header("可设置值")]
	[Tooltip("掉血显示")] public GameObject bloodDownPrefab;
	[Tooltip("射击距离")] public float shootDistance = 30.0f;
	[Tooltip("子弹射击伤害")] public float bulletHurtValue = 20.0f;//
	[Tooltip("子弹射击时间间隔")] public float bulletCoolLevelMax = 0.3f;//以秒为单位
	[Tooltip("子弹一弹夹子弹量")] public int bulletClipMax = 30;
	[Tooltip("激光射击伤害")] public float laserHurtValue = 0.2f;//
	[Tooltip("激光最大容量")] public int laserClipMax = 200;
	[Tooltip("激光恢复速率")] public int laserRestoreSpeed = 3;
	[Tooltip("火焰射击伤害")] public float fireHurtValue = 0.2f;//
	[Tooltip("火焰射击喷射时间")] public int fireShootLevelMax = 600;
	[Tooltip("火焰过热冷却时间")] public int fireCoolLevelMax = 180;
	[Tooltip("子弹生成地点")] public Transform gun;
	[Tooltip("子弹生成地点")] public Transform gunL;
	[Tooltip("子弹生成地点")] public Transform gunR;
	[Tooltip("子弹预置体")] public GameObject bulletPrefab;
	[Tooltip("激光预置体")] public GameObject laserPrefab;
	[Tooltip("火焰预置体")] public GameObject firePrefab;
	[Tooltip("火花预置体")] public GameObject sparkPrefab;
	

	private UIPlayerShoot UIShoot;//射击界面
	private UISecondBlood UISecBlood;//血量显示界面
	private UIDialogue UITip;
	private Ray ray;//射线
	private RaycastHit hit;//射线信息
	private int layerMask;//射线检测层信息
	private Vector3 targetPositionT;//记录目标点
	private float bulletCoolLevel;//射击冷却计时器
	private int bulletShootLevel;//子弹计数器
	private bool bulletCanShoot;
	private int laserShootLevel;//激光持续射击计数器
	private bool laserCanShoot;//
	private int fireShootLevel;//火焰持续射击计时器
	private int fireCoolLevel;//火焰冷却计时器
	public float playerHurtBuff;
	

	void Awake()
	{
		layerMask = 1 << 2;
		layerMask = ~layerMask;
		
		laserPrefab.SetActive(false);
		firePrefab.SetActive(false);
		
		bulletCoolLevel = 0.0f;
		bulletShootLevel = bulletClipMax;
		bulletCanShoot = true;
		laserShootLevel = laserClipMax;
		laserCanShoot = true;
		fireShootLevel = 0;
		fireCoolLevel = 0;

		shootType = ShootType.Bullet;
		bloodDownNum = 0.0f;
		bloodDownTime = bloodDownTimeMax;
		playerHurtBuff = 0;
	}
	void Start () {
		UIShoot = UIManager.playerShootUI;
		UIShoot.SetShootType(shootType, GetHurtValue());
		UIShoot.SetShootSlider(bulletShootLevel,bulletClipMax);
		UISecBlood = UIManager.secondBloodUI;
		UITip = UIManager.dialogueUI;
		UIManager.SetSecondBloodShow(false);
	}
	void Update () {
		GunChanging();
		Aiming();
		Shooting();
	}

	public float GetHurtValue()
	{
		float hurtValueT;
		switch(shootType)
		{
			case ShootType.Bullet:hurtValueT = bulletHurtValue + playerHurtBuff;break;
			case ShootType.Laser:hurtValueT = (laserHurtValue + playerHurtBuff) * Time.deltaTime;break;
			case ShootType.Fire:hurtValueT = (fireHurtValue + playerHurtBuff) * Time.deltaTime;break;
			default:hurtValueT = 1;break;
		}
		return hurtValueT;
	}

	private void GunChanging()
	{
		if(Input.GetKeyDown(KeyCode.Q))
		{
			if(shootType == ShootType.Bullet)
			{
				shootType = ShootType.Laser;
				UIShoot.SetShootSlider(laserShootLevel,laserClipMax);
			}
			else if(shootType == ShootType.Laser)
			{
				laserPrefab.SetActive(false);
				shootType = ShootType.Fire;
				UIShoot.SetShootSlider(fireShootLevel,fireShootLevelMax);
			}
			else if(shootType == ShootType.Fire)
			{
				firePrefab.SetActive(false);
				shootType = ShootType.Bullet;
				UIShoot.SetShootSlider(bulletShootLevel,bulletClipMax);
			}
			UIShoot.SetShootType(shootType, GetHurtValue());
		}
	}
	private void Aiming()
	{
		// ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		ray = new Ray(Camera.main.transform.position,Camera.main.transform.forward);
		if(Physics.Raycast(ray,out hit,shootDistance,layerMask))
		{
			targetPositionT = hit.point;
			if(hit.transform.CompareTag("ColorMonster"))
			{
				UIManager.SetSecondBloodShow(true);
				var script = hit.transform.GetComponent<ColorMonster>();
				UISecBlood.SetbloodValue(script.blood, script.bloodMax);
			}
			else if(hit.transform.CompareTag("GreenMonster"))
			{
				UIManager.SetSecondBloodShow(true);
				var script = hit.transform.GetComponent<GreenMonster>();
				UISecBlood.SetbloodValue(script.blood, script.bloodMax);
			}
			else if(hit.transform.CompareTag("CanBeHurt"))
			{
				UIManager.SetSecondBloodShow(true);
				var script = hit.transform.GetComponent<CanBeHurt>();
				UISecBlood.SetbloodValue(script.blood, script.bloodMax);
			}
			else if(hit.transform.CompareTag("ColorTrap"))
			{
				UIManager.SetSecondBloodShow(true);
				var script = hit.transform.GetComponent<ColorTrap>();
				UISecBlood.SetbloodValue(script.blood, script.bloodMax);
			}
			else if(hit.transform.CompareTag("ColorTrapDown"))
			{
				UIManager.SetSecondBloodShow(true);
				var script = hit.transform.GetComponent<ColorTrapDown>();
				UISecBlood.SetbloodValue(script.blood, script.bloodMax);
			}
			else
			{
				UIManager.SetSecondBloodShow(false);
			}
		}
		else
		{
			targetPositionT = ray.GetPoint(shootDistance);
			UIManager.SetSecondBloodShow(false);
		}
		gun.LookAt(targetPositionT);
		Debug.DrawLine(gun.position,targetPositionT,Color.red);
	}
	public void Shooting()//射击
	{
		switch(shootType)
		{
			case ShootType.Bullet:BulletShooting();break;
			case ShootType.Laser:LaserShooting();break;
			case ShootType.Fire:FireShooting();break;
		}
	}
	private void RayHurt()//射线检测
	{
		if(shootType == ShootType.Bullet)
		{
			GameObject sparkT = Instantiate(sparkPrefab,hit.point,Quaternion.Euler(gun.forward));
			Destroy(sparkT,1.0f);
		}
		
		ray = new Ray(gun.position,gun.forward);
		RayHurtDetect();
		if(shootType == ShootType.Fire)
		{
			ray = new Ray(gun.position,gunL.forward);
			RayHurtDetect();
			ray = new Ray(gun.position,gunR.forward);
			RayHurtDetect();
		}
	}
	private void RayHurtDetect()//射线检测并造成伤害
	{
		if(Physics.Raycast(ray,out hit,shootDistance,layerMask))
		{
			Debug.DrawLine(gun.position,hit.point,Color.red,1.0f);
			if(hit.transform.CompareTag("ColorMonster"))
			{
				float hurtValueT = GetHurtValue();
				if(shootType == ShootType.Bullet)
				{
					hit.transform.GetComponent<GreenMonster>().Repelled(gun.forward);
				}
				else if(shootType == ShootType.Fire)
				{
					hurtValueT *= 2;
				}
				hit.transform.GetComponent<ColorMonster>().Hurt(hurtValueT);
				bloodDownNum += hurtValueT;
			}
			else if(hit.transform.CompareTag("GreenMonster"))
			{
				float hurtValueT = GetHurtValue();
				if(shootType == ShootType.Bullet)
				{
					hit.transform.GetComponent<GreenMonster>().Repelled(gun.forward);
				}
				else if(shootType == ShootType.Fire)
				{
					hurtValueT *= 2;
				}
				hit.transform.GetComponent<GreenMonster>().Hurt(hurtValueT);
				bloodDownNum += hurtValueT;
				// UISecBlood.SetBloodValueChange(GetHurtValue(),false);
				
			}
			else if(hit.transform.CompareTag("CanBeHurt"))
			{
				float hurtValueT = GetHurtValue();
				if(shootType == ShootType.Laser)
				{
					hurtValueT *= 2;
				}
				hit.transform.GetComponent<CanBeHurt>().Hurt(hurtValueT);
				bloodDownNum += hurtValueT;
			}
			else if(hit.transform.CompareTag("Operating"))
			{
				hit.transform.GetComponent<Operating>().Work();
			}
			else if(hit.transform.CompareTag("ColorTrap"))
			{
				hit.transform.GetComponent<ColorTrap>().Work();
			}
		}
	}

	private void ShowBloodDown()//伤害显示
	{
		if(bloodDownNum >= 1.0f)
		{
			GameObject bloodDownT = Instantiate(bloodDownPrefab, hit.point, Quaternion.Euler(this.transform.forward));
			bloodDownT.GetComponent<TextMesh>().text = "-" + Mathf.RoundToInt(bloodDownNum);
			bloodDownNum = 0.0f;
		}
	}
	private void BulletShooting()//当前装备的是子弹枪，此函数每帧执行一次
	{
		if(Input.GetKeyDown(KeyCode.R))
		{
			bulletShootLevel = 0;
			bulletCanShoot = false;
		}
		if(bulletCoolLevel > 0.0f)
		{
			bulletCoolLevel -= Time.deltaTime;
		}
		else
		{
			if(bulletCanShoot)
			{
				if(Input.GetMouseButton(0) && GameManager.FPC.isDead == false)
				{
					GameObject.Instantiate(bulletPrefab,gun.position,Quaternion.Euler(gun.eulerAngles));
					RayHurt();
					bulletShootLevel --;
					if(bulletShootLevel == 0)
					{
						bulletCanShoot = false;
					}
					bulletCoolLevel = bulletCoolLevelMax;
					UIShoot.SetShootSlider(bulletShootLevel,bulletClipMax);
					ShowBloodDown();
				}
			}
			else//!bulletCanShoot
			{
				bulletShootLevel++;
				if(bulletShootLevel >= bulletClipMax)
				{
					bulletCanShoot = true;
					bulletShootLevel = bulletClipMax;
				}
				UIShoot.SetShootSlider(bulletShootLevel,bulletClipMax);
			}
		}
		//其他枪的冷却正常进行
		if(laserShootLevel < 0)
		{
			laserShootLevel ++;
			UIShoot.SetShootSlider(laserShootLevel, laserClipMax);
		}
		if(fireShootLevel > 0)
		{
			fireShootLevel -= 1;
		}
	}
	private void LaserShooting()//当前装备的是激光枪，此函数每帧执行一次
	{
		if(laserShootLevel < 0)//枪过热
		{
			laserShootLevel ++;
			UIShoot.SetShootSlider(laserShootLevel, laserClipMax);
		} 
		else
		{
			if(laserCanShoot && Input.GetMouseButton(0) && GameManager.FPC.isDead == false)
			{
				laserPrefab.SetActive(true);
				RayHurt();
				laserShootLevel--;
				if(laserShootLevel == 0)
				{
					laserPrefab.SetActive(false);
					laserCanShoot = false;
				}
				
				bloodDownTime --;
				if(bloodDownTime <= 0)
				{
					ShowBloodDown();
					bloodDownTime = bloodDownTimeMax;
				}
			}
			else
			{
				laserPrefab.SetActive(false);
				laserShootLevel += laserRestoreSpeed;
				if(laserShootLevel > laserClipMax / 2)
				{
					laserCanShoot = true;
					if(laserShootLevel > laserClipMax)
					{
						laserShootLevel = laserClipMax;
					}
				}
			}
			UIShoot.SetShootSlider(laserShootLevel, laserClipMax);
		}
		//其他枪的冷却正常进行
		if(fireShootLevel > 0)
		{
			fireShootLevel -= 1;
		}
	}
	private void FireShooting()//当前装备的是火焰枪，此函数每帧执行一次
	{
		if(fireCoolLevel > 0)
		{
			fireCoolLevel --;
			UIShoot.SetShootSlider(fireCoolLevel, fireCoolLevelMax);
		}
		else
		{
			if(Input.GetMouseButton(0) && GameManager.FPC.isDead == false)
			{
				firePrefab.SetActive(true);
				RayHurt();
				fireShootLevel++;
				if(fireShootLevel >= fireShootLevelMax)
				{
					firePrefab.SetActive(false);
					fireShootLevel = 0;
					fireCoolLevel = fireCoolLevelMax;
				}

				bloodDownTime --;
				if(bloodDownTime <= 0)
				{
					ShowBloodDown();
					bloodDownTime = bloodDownTimeMax;
				}
			}
			else
			{
				firePrefab.SetActive(false);
				if(fireShootLevel > 0)
				{
					fireShootLevel -= 1;
				}
			}
			UIShoot.SetShootSlider(fireShootLevel, fireShootLevelMax);
		}
		//其他枪的冷却正常进行
		if(laserShootLevel < 0)
		{
			laserShootLevel ++;
			UIShoot.SetShootSlider(laserShootLevel, laserClipMax);
		}
	}
	public void ChangePlayerHurtBuff(float value, bool isAdd)
	{
		playerHurtBuff = isAdd ? playerHurtBuff + value : playerHurtBuff - value;
		Debug.Log("攻击力加成" + playerHurtBuff);
		if(isAdd)
		{
			UITip.SetDialogue("攻击力" + "+" + value);
		}
		else
		{
			UITip.SetDialogue("攻击力" + "-" + value);
		}
		UIShoot.SetShootType(shootType, GetHurtValue());
	}



}
}
