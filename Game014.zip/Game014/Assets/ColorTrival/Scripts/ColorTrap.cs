﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public enum TrapColor{
	Red,
	Orange,
	Blue,
	Green,
	Purple,
	Black,
	White,
}

public class ColorTrap : MonoBehaviour {

	public TrapColor colorNow = TrapColor.White;
	public int bloodMax = 3;
	public int blood;
	public float workCoolMax = 1.0f;
	public float respawnTime = 30.0f;
	public int goldLevel = 1000;

	private FirstPlayerController FPC;
	private UIDialogue UITip;
	private int rand;
	private float workCoolTime;
	void Awake()
	{
		blood = bloodMax;
		workCoolTime = 0.0f;
	}
	void Start () {
		FPC = GameManager.FPC;
		UITip = UIManager.dialogueUI;
	}
	void Update () {
		if(workCoolTime >0.0f)
		{
			workCoolTime -= Time.deltaTime;
		}
	}
	

	public void Work()
	{
		if(workCoolTime <= 0.0f)
		{
			rand = Random.Range(0,100);
			// Debug.Log("随机数:" + rand);
			Hurt();
			switch(colorNow)
			{
				case TrapColor.Red:RedTrap();break;
				case TrapColor.Orange:OrangeTrap();break;
				case TrapColor.Blue:BlueTrap();break;
				case TrapColor.Green:GreenTrap();break;
				case TrapColor.Purple:PurpleTrap();break;
				case TrapColor.Black:BlackTrap();break;
				case TrapColor.White:WhiteTrap();break;
				default:break;
			}
			workCoolTime = workCoolMax;
		}
	}

	private void Hurt()//被射击或者被触发时损失耐久
	{
		blood--;
		if(blood <= 0)
		{
			this.gameObject.SetActive(false);
			Invoke("Respawn",respawnTime);
			// Destroy(this.gameObject,0.5f);
		}
	}

	private void Respawn()//恢复
	{
		blood = bloodMax;
		this.gameObject.SetActive(true);
	}

	private void RedTrap()//红
	{
		if(rand < 80)
		{
			int healValue = 20;
			FPC.Heal(healValue);
		}
		else
		{
			int healValue = 50;
			FPC.Heal(healValue);
		}
	}
	private void OrangeTrap()//橘
	{
		if(rand < 50)
		{
			int burnLevel = 5,burnTime = 3;
			FPC.Burned(burnLevel,burnTime);
		}
		else
		{
			int burnLevel = 10,burnTime = 2;
			FPC.Burned(burnLevel,burnTime);
		}
	}
		private void BlueTrap()//蓝
	{
		if(rand < 80)
		{
			FPC.Clear();
		}
	}
		private void GreenTrap()//绿
	{
		if(rand<90)
		{
			int poisonLevel = 5;
			FPC.Poisoned(poisonLevel);
		}
		else
		{
			int healValue = 50;
			FPC.Heal(healValue);
		}
	}
	private void PurpleTrap()//紫
	{
		if(GameManager.playerGold >= goldLevel)
		{
			UIManager.playerGoldUI.SetGoldValueChange(goldLevel, false);
			GameManager.player.GetComponent<Shoot>().ChangePlayerHurtBuff(5.0f,true);
			FPC.SetPlayerBloodMaxAdd(10.0f, true);
			goldLevel += 1000;
		}
		else
		{
			UITip.SetDialogue("金币不足。需要" + goldLevel + "。");
		}
	}
		private void BlackTrap()//黑
	{
		if(rand < 100)
		{
			blood = bloodMax;
		}
	}
		private void WhiteTrap()//白
	{
		if(rand < 100)
		{
			blood = bloodMax;
		}
	}

	
		
}
}
