﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class Task : MonoBehaviour {

	public UITaskProgress taskManager;
	void Awake()
	{
	}
	void Start () {
		
	}
	void Update () {
		
	}
	void OnDestroy()
	{
		taskManager.TaskProgressAdd();
	}
}


}
