﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{



public class MonstersCreateMore : MonoBehaviour {

	public GameObject monsterPrefab;
	[Tooltip("玩家靠近开始刷怪的距离")] public float feelRadius = 15;
	[Tooltip("刷怪的范围，正方形区域半径")] public float createRedius = 25;
	[Tooltip("刷怪冷却时间")] public float createCoolDown = 3.0f;
	[Tooltip("刷怪冷却时间加速度")] public float createTimeDownSpeed = 0.1f;
	[Tooltip("刷怪冷却时间最小值")] public float createCoolDownMin = 0.1f;

	private BoxCollider boxCld;
	private Vector3 offset;
	private Vector3 positionT;
	private float createCoolLevel;
	void Awake()
	{
		boxCld = this.GetComponent<BoxCollider>();
		createCoolLevel = 0.0f;
	}
	void Start () {
		boxCld.size = new Vector3(feelRadius,boxCld.size.y,feelRadius);
	}
	
	void Update () {
		if(createCoolLevel > 0.0f)
		{
			createCoolLevel -= Time.deltaTime;
		}
	}

	void OnTriggerStay(Collider col)
	{
		if(col.CompareTag("Player") && createCoolLevel <= 0)
		{
			CreateMonster();
		}
	}
	void CreateMonster()
	{
		offset = new Vector3(Random.Range(-createRedius,createRedius),1.0f,Random.Range(-createRedius,createRedius));
		positionT = this.transform.position + offset;
		Instantiate(monsterPrefab,positionT,Quaternion.identity);
		createCoolDown -= createTimeDownSpeed;
		if(createCoolDown <= createCoolDownMin)
		{
			createTimeDownSpeed = 0.0f;
		}
		createCoolLevel = createCoolDown;
	}
}


}



