﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fireworks : MonoBehaviour 
{
    public int numMax = 30;
    public int numMin = 10;
    public float radius = 1.0f;
    public float liveTimeMax = 8.0f;
    public float liveTimeMin = 2.0f;
    public GameObject pfbFire;
    public float forceK = 10.0f;
    public Vector3 forceUp = new Vector3(0.0f, 1.0f, 0.0f);

    void Awake () 
	{
		
	}

	void Start () 
	{
		
	}
	
	void Update () 
	{
		
	}

	void LateUpdate () 
	{
		
	}

	void FixedUpdate () 
	{
		
	}

    public void Show()
    {
        if(pfbFire == null)
        {
            return;
        }

        int num = (int)(Random.value * (numMax - numMin) + numMin);

        float liveTimeL = 0.0f;
        for(int i=0;i<num;i++)
        {
            Vector3 position = new Vector3();
            position.x = Random.value * radius * 2 - radius;
            position.y = Random.value * radius * 2 - radius;
            position.z = Random.value * radius * 2 - radius;
            GameObject objFire = Instantiate(pfbFire, this.transform);
            objFire.transform.localPosition = position;
            Rigidbody rigidbody = objFire.GetComponent<Rigidbody>();
            Vector3 force = objFire.transform.position - this.transform.position + forceUp;
            rigidbody.AddForce(force * forceK);
            
            float liveTime = Random.value * (liveTimeMax - liveTimeMin) + liveTimeMin;
            Destroy(objFire, liveTime);
            if(liveTime > liveTimeL)
            {
                liveTimeL = liveTime;
            }
        }
        Destroy(this.gameObject, liveTimeL);
    }
}
