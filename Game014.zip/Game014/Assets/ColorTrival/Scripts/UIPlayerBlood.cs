﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UIPlayerBlood : MonoBehaviour {
	
	[Tooltip("玩家血量变化初始颜色")] public Color colorStart;//
	[Tooltip("玩家血量变化最终颜色")] public Color colorEnd;//
	[Tooltip("玩家血量进度条")] public Slider sldBlood;//
	[Tooltip("玩家血量")] public Text txtBloodValue;//
	[Tooltip("玩家血量变化")] public Text txtBloodValueChange;//
	[Tooltip("玩家血量变化显示时间(s)")] public float tBloodValueChangeLevelMax = 5.0f;//
	[Tooltip("玩家血量变化剩余显示时间(s)")] public float tBloodValueChangeLevel;//

	void Awake() {
	}
	void Start () {
	}
	void Update () {
		Lightening();
	}

	private void Lightening()//字体的颜色会慢慢变淡
	{
		if(tBloodValueChangeLevel > 0.0f)//血量变化显示
		{
			txtBloodValueChange.color = Color.Lerp(colorEnd, colorStart, tBloodValueChangeLevel / tBloodValueChangeLevelMax );
			tBloodValueChangeLevel -= Time.deltaTime;
		}
		else
		{
			txtBloodValueChange.color = colorEnd;
			tBloodValueChangeLevel = 0.0f;
		}
	}
	public void SetbloodValue(float blood, float bloodMax)//设置玩家血量条的值
	{
		sldBlood.maxValue = bloodMax;
		sldBlood.value = blood;
		txtBloodValue.text = Mathf.Round(blood) + "/" + Mathf.Round(bloodMax);
	}

	public void SetBloodValueChange(float value, bool isAdd)
	{
		int valueT = (int)value;
		txtBloodValueChange.text = isAdd ? "+" + valueT.ToString() : "-" + valueT.ToString();
		tBloodValueChangeLevel = tBloodValueChangeLevelMax;
	}
}


}
