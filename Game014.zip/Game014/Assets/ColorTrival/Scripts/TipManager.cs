﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class TipManager : MonoBehaviour {

	public float showDistance = 20.0f;

	private Transform playerTr;
	private GameObject[] tips;
	private float distanceT;
	void Awake()
	{
		tips = GameObject.FindGameObjectsWithTag("Tip");
	}
	void Start () {
		playerTr = GameManager.player.transform;
	}
	void Update () {
		foreach(GameObject T in tips)
		{
			distanceT = Vector3.Distance(T.transform.position,playerTr.position);
			if(distanceT <= showDistance)
			{
				T.gameObject.SetActive(true);
				T.transform.localScale = new Vector3(1 - distanceT/showDistance, 1 - distanceT/showDistance, 1 - distanceT/showDistance);
				T.transform.eulerAngles = playerTr.eulerAngles;
			}
			else
			{
				T.gameObject.SetActive(false);
			}
		}
		
		
	}
}


}