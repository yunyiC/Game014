﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace ColorTrival{


public class UIDialogue : MonoBehaviour {
	
	[Tooltip("文字初始颜色")] public Color colorStart;//
	[Tooltip("文字最终颜色")] public Color colorEnd;//
	[Tooltip("文字显示时间(s)")] public float tColorChangeLevelMax = 5.0f;//
	[Tooltip("对话")] public Text txtDialogue;//
	[Tooltip("文字剩余显示时间(s)")] public float tColorChangeLevel;//
	

	void Awake() {
	}
	void Start () {
	}
	void Update () {
		Lightening();
	}

	private void Lightening()//字体的颜色会慢慢变淡
	{
		if(tColorChangeLevel > 0.0f)//血量变化显示
		{
			txtDialogue.color = Color.Lerp(colorEnd, colorStart, tColorChangeLevel / tColorChangeLevelMax );
			tColorChangeLevel -= Time.deltaTime;
		}
		else
		{
			txtDialogue.color = colorEnd;
			tColorChangeLevel = 0.0f;
		}
	}
	public void SetDialogue(string str)
	{
		txtDialogue.text = str;
		tColorChangeLevel = tColorChangeLevelMax;
	}
}


}
