﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


public class FireBall : MonoBehaviour
{
    public int hurtLevel = 1;
    public int hurtTime = 1;
	void Start () {
	}
	void Update () {
    }
    private void OnParticleCollision(GameObject col)
    {
        if (col.CompareTag("Player"))
        {
            GameManager.FPC.Burned(hurtLevel, hurtTime);
        }
    }

}


}
