﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace ColorTrival{


public enum MonsterType{
	GreenMonster,
}

public enum MonsterState{
	Attacking,
	Tracking,
	Patroling,
	Waiting,
}

public class ColorMonster : MonoBehaviour {

	[Header("观测值:")]
	[Tooltip("当前状态。")] public MonsterState stateNow;
	[Tooltip("临时目标。")] public Vector3 targetV3;
	[Tooltip("与目标的距离。")] public float distanceT;
	[Tooltip("目标标记")] public Transform targetMark;
	[Tooltip("血量。")] public float blood;
	[Tooltip("停留时间。")] public int stayTimes = 0;
	[Tooltip("跟踪耐心。")] public int patientLevel;
	[Tooltip("攻击后的冷却的剩余时间。")] public float attackCoolLevel;


	[Header("属性值:")]
	[Tooltip("死亡高度。")] public float deadLine = -15.0f;
	[Tooltip("死亡距离。")] public float deadDistance = 50.0f;
	[Tooltip("追踪敌人的速度。")] public float followSpeed = 5.0f;
	[Tooltip("感知半径。")] public float feelRadius = 10.0f;
	[Tooltip("活动半径。")] public float patrolRadius = 20.0f;
	[Tooltip("攻击半径。")] public float attackRadius = 1.5f;
	[Tooltip("攻击伤害。")] public int hurtValue = 10;
	[Tooltip("攻击冷却时间。")] public float attackCoolDown = 3.0f;
	[Tooltip("血量上限。")] public float bloodMax = 100;

	private UISecondBlood UISecBlood;
	private UIPlayerGold UIGold;
	private NavMeshAgent NMA;//AI组件
	private Transform playerTransform;//用于实时获取玩家的位置
	private int patientLevelMax;//跟踪耐心上限
	private Vector3 lastPositionT;//记录上一帧的位置，避免停留某处太久。

	void Awake()
	{
		stateNow = MonsterState.Patroling;
		targetV3 = this.transform.position;
		if(targetMark != null)
		{
			targetMark.position = targetV3;
		}
		NMA = this.GetComponent<NavMeshAgent>();
		patientLevelMax = 200;
		patientLevel = 0;
		attackCoolLevel = 0.0f;
		blood = bloodMax;
		lastPositionT = this.transform.position;
	}
	void Start()
	{
		UISecBlood = UIManager.secondBloodUI;
		UIGold = UIManager.playerGoldUI;
		playerTransform = GameManager.player.transform;
	}
	void Update()
	{
		if(this.transform.position.y < deadLine)
		{
			Destroy(this.gameObject,0.0f);
		}
		else
		{
			NMA.speed = followSpeed;
			distanceT = Vector3.Distance(this.transform.position,playerTransform.position);
			if(distanceT > deadDistance)
			{
				Destroy(this.gameObject,0.0f);
			}
			else
			{
				switch(stateNow)
				{
					case MonsterState.Attacking:Attacking();break;
					case MonsterState.Tracking:Tracking();break;
					case MonsterState.Patroling:Patroling();break;
					case MonsterState.Waiting:Waiting();break;
					default:break;
				}
			}
			
		}
	}

	public void Hurt(float hurtValue)
	{
		if(hurtValue >= blood)
		{
			// UISecBlood.SetBloodValueChange(blood, false);
			UIGold.SetGoldValueChange(10,true);//玩家金币加10
			Destroy(this.gameObject,0.0f);
		}
		else
		{
			blood -= hurtValue;
			UISecBlood.SetbloodValue(blood, bloodMax);
			// UISecBlood.SetBloodValueChange(hurtValue,false);
			patientLevel = patientLevelMax;
			stateNow = MonsterState.Tracking;
		}
	}

	public void Repelled(Vector3 d)//被击退
	{
		this.transform.position += d;
	}
	private void Attacking()//攻击
	{
		if(distanceT >= feelRadius)
		{
			stateNow = MonsterState.Tracking;
		}
		else
		{
			followSpeed = 6.0f;
			NMA.SetDestination(playerTransform.position);
			if(targetMark != null)
			{
				targetMark.position = playerTransform.position;
			}
			patientLevel = patientLevelMax;
			if((attackCoolLevel <= 0.0f) && (distanceT <= attackRadius) && (GameManager.FPC.isDead == false))
			{
				Attack();
			}
		}
	}
	private void Tracking()//追踪
	{
		if(distanceT < feelRadius)
		{
			stateNow = MonsterState.Attacking;
		}
		else
		{
			if(patientLevel < 0)
			{
				stateNow = MonsterState.Patroling;
				
			}
			else
			{
				followSpeed = 8.0f;
				patientLevel--;
				NMA.SetDestination(playerTransform.position);
				if(targetMark != null)
				{
					targetMark.position = playerTransform.position;
				}
			}
		}
	}

	private void Patroling()//巡逻
	{
		if(distanceT < feelRadius)
		{
			stateNow = MonsterState.Attacking;
		}
		else
		{
			followSpeed = 3.0f;
			Vector3 offset;
			
			distanceT = Vector3.Distance(this.transform.position,lastPositionT);
			// Debug.Log(distanceT + "");
			lastPositionT = this.transform.position;
			if(distanceT < 0.06f)
			{
				stayTimes++; 
			}
			else
			{
				stayTimes = 0;
			}
			if(stayTimes > 200)
			{
				stayTimes = 0;
				offset = new Vector3(Random.Range(-patrolRadius,patrolRadius),0.0f, Random.Range(-patrolRadius,patrolRadius) );
				targetV3 = this.transform.position + offset;
			}
			
			NMA.SetDestination(targetV3);
			if(targetMark != null)
			{
				targetMark.position = targetV3;
			}

			distanceT = Vector3.Distance(this.transform.position,targetV3);
			if(distanceT > attackRadius)
			{
				//继续追临时目标
			}
			else
			{//追到了临时目标
				offset = new Vector3(Random.Range(-patrolRadius,patrolRadius),0.0f, Random.Range(-patrolRadius,patrolRadius) );
				targetV3 = this.transform.position + offset;
				NMA.SetDestination(targetV3);//建立新的目标点
				if(targetMark != null)
				{
					targetMark.position = targetV3;
				}
			}
		}	
	}
	private void Waiting()//攻击之后的恢复
	{
		if(attackCoolLevel > 0)
		{
			attackCoolLevel -= Time.deltaTime;
			followSpeed = 0.0f;
			this.transform.Rotate(0.0f,1.0f,0.0f);
		}
		else
		{
			stateNow = MonsterState.Patroling;
		}
	}
	private void Attack()
	{
		GameManager.FPC.Hurt(hurtValue);
		GameManager.FPC.Repelled(playerTransform.position - this.transform.position);
		attackCoolLevel = attackCoolDown;
		patientLevel = 0;
		
		stateNow = MonsterState.Waiting;
	}


}
}