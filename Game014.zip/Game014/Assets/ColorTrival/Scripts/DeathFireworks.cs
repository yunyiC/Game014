﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathFireworks : MonoBehaviour 
{
    public GameObject pfbFireworks;

	void Awake () 
	{
		
	}

	void Start () 
	{
		
	}
	
	void Update () 
	{
		
	}

	void LateUpdate () 
	{
		
	}

	void FixedUpdate () 
	{
		
	}

    void OnDestroy()
    {
        if ( pfbFireworks != null)
        {
            GameObject objFireworks = Instantiate(pfbFireworks);
            Fireworks fireworks = objFireworks.GetComponent<Fireworks>();
            fireworks.Show();
            objFireworks.transform.position = this.transform.position;
        }
    }
}
