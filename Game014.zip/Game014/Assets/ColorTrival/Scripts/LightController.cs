﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ColorTrival{


	
public class LightController : MonoBehaviour {

	public KeyCode lightKey = KeyCode.G;
	private Light lightA;
	void Awake()
	{
		lightA = this.GetComponent<Light>();
		lightA.enabled = false;
	}
	void Start () {
		
	}
	void Update () {
		if(Input.GetKeyDown(lightKey))
		{
			if(lightA.enabled == false)
			{
				lightA.enabled = true;
			}
			else{
				lightA.enabled = false;
			}
		}
	}



}
}
