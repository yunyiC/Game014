﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sky : MonoBehaviour {
    public float speed;
    public float CD;
    public GameObject bullet;
    public GameObject Object;
    [Header ("随机范围")]
    public float randon=500;
	// Use this for initialization
	void Start () {

        q();
        
	}
	
	// Update is called once per frame
	void Update () {
        transform.localPosition = new Vector3(Random.Range(-randon, randon), Random.Range(-randon, randon), Random.Range(-randon, randon));
	}
    void q()
    {
        GameObject a = Instantiate(bullet, Object.transform.position, Object.transform.rotation) as GameObject;
        a.GetComponent<Rigidbody>().velocity = transform.forward * speed;
        Invoke("q", Random.Range(0, CD));
    }
}
