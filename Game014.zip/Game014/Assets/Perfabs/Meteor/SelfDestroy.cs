﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelfDestroy : MonoBehaviour {
    public float maxtime=10;
	// Use this for initialization
	void Start () {
        Destroy(transform.gameObject, Random.Range(0, maxtime));
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
